<?php

class Notiflist extends Database {  
    
	private $departmentsTable = 'notifications';
	
	private $dbConnect = false;
	public function __construct(){		
        $this->dbConnect = $this->dbConnect();
    } 
	public function listNotifications(){
			 			 
		$sqlQuery = "SELECT id, title, message, ntime, username
			FROM ".$this->departmentsTable;
			
		
		if(!empty($_POST["order"])){
			$sqlQuery .= ' ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
		} else {
			$sqlQuery .= ' ORDER BY id DESC ';
		}
		if($_POST["length"] != -1){
			$sqlQuery .= ' LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
		}	
		
		$result = mysqli_query($this->dbConnect, $sqlQuery);
		$numRows = mysqli_num_rows($result);
		$departmentData = array();	
		while( $department = mysqli_fetch_assoc($result) ) {		
			$departmentRows = array();			
			
			$departmentRows[] = $department['id'];
			$departmentRows[] = $department['title'];			
			$departmentRows[] = $department['message'];
			$departmentRows[] = $department['ntime'];
			$departmentRows[] = $department['username'];
			$departmentData[] = $departmentRows;
		}
		$output = array(
			"draw"				=>	intval($_POST["draw"]),
			"recordsTotal"  	=>  $numRows,
			"recordsFiltered" 	=> 	$numRows,
			"data"    			=> 	$departmentData
		);
		echo json_encode($output);
	}	
	
		
	
	
	
	
}