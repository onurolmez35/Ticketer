<?php 
include 'init.php'; 


if(!$users->isLoggedIn()) {
	header("Location: login.php");	
}
include('inc/header.php');
$user = $users->getUserInfo();
?>
<title>Ticketing System</title>
<script src="js/notification.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<script src="js/general.js"></script>
<script src="js/tickets.js"></script>
<link rel="stylesheet" href="css/style.css" />
<?php include('inc/container.php');?>
<div class="container">	
	<div class="row home-sections">
	<h2></h2>	
	<?php include('menus.php'); ?>		
	</div> 
	<div style="padding-bottom: 10px;">
		<div class="row">
			<div class="col-md-10">
				<h3 class="panel-title"></h3>
			</div>
			<div class="col-md-2" align="right">
				
				<button type="button" name="add" id="createTicket" class="button button1 glyphicon glyphicon-paste"></button>
				
			</div>
			
		</div>
		
	</div>
	
	<div class="">   		
		

			
		
		<table id="listTickets" class="table table-bordered table-striped">
			<thead>
				<tr>
					<th>ID</th>
					<th></th>
					<th>Ticket ID</th>
					<th>Subject</th>
					<th>Type</th>
					<th>Creator</th>
					<th>Responsible</th>					
					<th>Date</th>	
					<th>Status</th>
					<th>View</th>
					<th>Edit</th>
					<th>Close</th>	
							
				</tr>
			</thead>
		</table>
	</div>
	<?php include('add_ticket_model.php'); ?>
</div>	
<?php include('inc/footer.php');?>