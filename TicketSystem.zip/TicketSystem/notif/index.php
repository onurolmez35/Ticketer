<?php 
SESSION_START();
include('inc/header.php');


?>

<title></title>
<script src="js/notification.js"></script>

<div class="container">		
	<h2></h2>	
	<h3>User Account </h3>
	<?php if(isset($_SESSION['username'])) { ?>
		<a href="manage.php">Manage Notification</a> | 
	<?php } ?>
	<?php if(isset($_SESSION['username'])) { ?>
		Logged in : <strong><?php echo $_SESSION['username']; ?></strong> | <a href="logout.php">Logout</a>
	<?php } else { ?>
		<a href="login.php">Login</a>
	<?php } ?>
	<hr> 
	<?php if (isset($_SESSION['username']) && $_SESSION['username']) { ?>
		<div <?php if($_SESSION['username'] != 'admin') { ?> id="loggedIn" <?php } header("Location: ../ticket.php");	 ?>>
			<h4>
				
			</h4>
		</div>
	<?php } ?>	
	
</div>	
<?php include('inc/footer.php');?>






