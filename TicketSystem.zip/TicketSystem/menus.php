<!-- nav class="navbar navbar-inverse" >
	<div class="container-fluid" id="loggedIn">		
		<ul class="nav navbar-nav menus">
			<li id="ticket"><a href="notif/index.php" class="navbar-brand">Ticket</a></li>
		
				<li id="department"><a href="department.php" >Department</a></li>
			<li id="notification"><a href="manage.php" >Notifications</a></li> 
			
				<li id="user"><a href="user.php" >Users</a></li>				
									
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count"></span> 
				<img </a>
							
					<li><a href="logout.php">Logout</a></li>
				
			</li>
		</ul>
	</div>
</nav> -->

	<div class="topnav" id="loggedIn">
	
	<a href="notif/index.php">Ticket</a>
	<?php if(isset($_SESSION["admin"])) { ?>
	<a href="department.php">Problem Types</a>
	<?php } ?>
	<a href="user.php">Users</a>
	<?php if(isset($_SESSION["admin"])) { ?>
	<a href="notiflist.php">Notification List</a>
	<?php } ?>
		<div style="padding-right:11px">
			<ul class="nav navbar-nav navbar-right">
				<li class="">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count"></span> 
					<img <?php echo md5($user['name']); ?> width="20px">&nbsp;<?php if(isset($_SESSION["userid"])) { echo $user['name']; } ?></a>
								
						<li><a href="logout.php">Logout</a></li>
					
				</li>
			</ul>
			
		</div>

	</div>
	<div class="col-md-10" style="padding-left:12px">
		<h2>Ticketing System</h2>
		<p>Create any ticket.</p>
		</div>




