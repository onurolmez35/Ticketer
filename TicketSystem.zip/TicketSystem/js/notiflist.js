$(document).ready(function() {        
	
	var departmentData = $('#listNotifications').DataTable({
		"searching": false,
		"lengthChange": false,
		"processing":true,
		"serverSide":true,
		"order":[],
		"ajax":{
			url:"notiflist_action.php",
			type:"POST",
			data:{action:'listNotifications'},
			dataType:"json"
		},
		"columnDefs":[
			{
				"targets":[0, 3, 4, 5],
				"orderable":false,
			},
		],
		"pageLength": 1000
	});	

	
    
});

