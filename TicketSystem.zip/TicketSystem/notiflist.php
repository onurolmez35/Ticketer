<?php 
include 'init.php'; 
if(!$users->isLoggedIn()) {
	header("Location: login.php");	
}
include('inc/header.php');
$user = $users->getUserInfo();
?>
<title>Ticketing System</title>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<script src="js/general.js"></script>
<script src="js/department.js"></script>
<link rel="stylesheet" href="css/style.css" />
<?php include('inc/container.php');?>
<div class="container">	
	<div class="row home-sections">
	<h2></h2>	
	<?php include('menus.php'); ?>		
	</div> 
	

			
	<table id="listNotif" class="table table-bordered table-striped">
		<thead>
			<tr>
				<th>ID</th>
				<th>Title</th>					
				<th>Message</th>
				<th>Created Date</th>
				<th>User Name</th>
				<th>Notification Left</th>
													
			</tr>
		</thead>
	</table>
	
	
</div>	
<?php include('inc/footer.php');?>