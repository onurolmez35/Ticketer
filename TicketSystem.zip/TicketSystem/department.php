<?php 
include 'init.php'; 
if(!$users->isLoggedIn()) {
	header("Location: login.php");	
}
include('inc/header.php');
$user = $users->getUserInfo();
?>
<title>Ticketing System</title>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<script src="js/general.js"></script>
<script src="js/department.js"></script>
<link rel="stylesheet" href="css/style.css" />
<?php include('inc/container.php');?>
<div class="container">	
	<div class="row home-sections">
	<h2></h2>	
	<?php include('menus.php'); ?>		
	</div> 
	
	<div>
		<div class="row">
			<div class="col-md-10">
				<h3 class="panel-title"></h3>
			</div>
			<div class="col-md-2" align="right">
				
				<button type="button" name="add" id="addDepartment" class="button button1 glyphicon glyphicon-paste"></button>
			</div>
		</div>
	</div>
			
	<table id="listDepartment" class="table table-bordered table-striped">
		<thead>
			<tr>
				<th>ID</th>
				<th>Problem Type</th>					
				<th>Status</th>
				<th>Created Date</th>
				<th>Edit</th>
				<th>Delete</th>										
			</tr>
		</thead>
	</table>
	
	<div id="departmentModal" class="modal fade">
		<div class="modal-dialog">
			<form method="post" id="departmentForm">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title"><i class="fa fa-plus"></i> Problem Type</h4>
					</div>
					<div class="modal-body">
						<div class="form-group"
							<label for="department" class="control-label">Problem Type</label>
							<input type="text" class="form-control" id="department" name="department" placeholder="Problem Type" required>			
						</div>
						<div class="form-group">
							<label for="status" class="control-label">Status</label>				
							<select id="status" name="status" class="form-control">
							<option value="1">Enable</option>				
							<option value="0">Disable</option>	
							</select>						
						</div>						
						
					</div>
					<div class="modal-footer">
						<input type="hidden" name="departmentId" id="departmentId" />
						<input type="hidden" name="action" id="action" value="" />
						<button type="submit" name="save" id="save" class="button6 glyphicon glyphicon-ok"></button>
					<button type="button" class="button7 glyphicon glyphicon-remove" data-dismiss="modal"></button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>	
<?php include('inc/footer.php');?>